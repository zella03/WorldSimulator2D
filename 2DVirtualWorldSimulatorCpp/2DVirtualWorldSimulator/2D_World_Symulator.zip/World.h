#pragma once
#include <iostream>
#include <vector>
#include <string>
#include "Organism.h"
#include "Reports.h"
#include "Defines.h"
using namespace std;

struct more_initiative
{
	inline bool operator() (const Organism* struct1, const Organism* struct2) {
		return ((*struct1).GetInitiative() > (*struct2).GetInitiative());
	}
};

class World {
	int horizSize;
	int verticSize;

	void addRandomOrganism(int numO, vector<Organism*>& whichVect);
	void killOrg();
public:
	vector<vector<Organism*>> organisms;
	vector<Organism*> fightList;
	vector<Organism*>newOrgList;
	MovementSide movementHuman;
	Reports* comentator;

	World();
	pos posFreeAround(Organism* org);
	void moveOrganism(Organism* organism, int numFields);
	void userWorld();
	void makeTurn();
	void drawWorld();
	pos randPosition();
	void addOrganism(pos position, Organism* organism, vector<Organism*>& whichVect, bool addToList);
	bool addConcreteOrganism(Organism* first, Organism* second, vector<Organism*>& whichVect);
	void OrganismActionCollision(Organism* org_);
	Organism* addByName(char name);

	void SetHorizSize(int horizSize);
	void SetVerticSize(int verticSize);
	int GetHorizSize() const;
	int GetVerticSize() const;

	~World();
};