#include <iostream>
#include "Sosnowsky_hogweed.h"
#include "World.h"

Sosnowsky_hogweed::Sosnowsky_hogweed() {
	this->name = 'h';
	this->strength = 10;
}

void Sosnowsky_hogweed::action(World* world) {
	//Kills every animal in its immediate neighborhood except cyber - sheep.
	if (position.x - 1 >= 0 ) {
		killAnimalAround(world, position.x - 1, position.y);
	}
	if (position.x + 1 < world->GetHorizSize()) {
		killAnimalAround(world, position.x + 1, position.y);
	}
	if (position.y - 1 >= 0) {
		killAnimalAround(world, position.x, position.y - 1);
	}
	if (position.y + 1 < world->GetVerticSize()) {
		killAnimalAround(world, position.x, position.y + 1);
	}
	this->SetOrganismWantedPosition(position.x, position.y);
}

void Sosnowsky_hogweed::killAnimalAround(World* world, int posX, int posY) {
	if (world->organisms[posY][posX] != nullptr && (world->organisms[posY][posX]->GetName() > LETTER_RANGE_ANIMAL_A 
		&& world->organisms[posY][posX]->GetName() < LETTER_RANGE_ANIMAL_Z)) {
		world->organisms[posY][posX]->SetOrganismLifespan(false);
		world->comentator->reportKill(this, world->organisms[posY][posX]);
		world->organisms[posY][posX] = nullptr;
	}
}

bool Sosnowsky_hogweed::collision(World* world,Organism* organismToFight) {
	//Kills any animal which eats it, apart from cyber - sheep.
	pos animalPos;
	if (this->isAttacker == true) {
		return true;
	}
	else {
		world->comentator->reportConsumption(organismToFight, this);
		world->comentator->reportKill(this, organismToFight);
		organismToFight->SetOrganismLifespan(false);
		this->isAlive = false;
		animalPos = organismToFight->GetOrganismPosition();
		world->organisms[animalPos.y][animalPos.x] = nullptr;
		world->organisms[position.y][position.x] = nullptr;
	}
	return true;
}

char Sosnowsky_hogweed::GetName() const {
	return 'h';
}

string Sosnowsky_hogweed::GetOrganismFullName() const {
	return "Sosnowsky_hogweed";
}

Sosnowsky_hogweed::~Sosnowsky_hogweed() {

}